package com.lexisnexis.telematics.infrastructure.domain;

public interface DomainEntityValidatorResolver {
	
	public DomainEntityValidator<?> getDomainValidator(String operation);
}
