package com.lexisnexis.telematics.infrastructure.domain;

public interface DomainEntity<TID> {
	public void setId(TID id);
	public TID getId();
}