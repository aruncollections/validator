package com.lexisnexis.telematics.infrastructure.domain;

public interface TelematicsDomainRule<T> {
	public abstract String getRuleCode();
	public abstract String getErrorMessage();
	public abstract void appendToErrorMessage(String identifier);
	public abstract boolean isValid(T entity);	
	public abstract String getEntityIdentifier();
	public abstract void setEntityIdentifier(String entityIdentifier);
}
