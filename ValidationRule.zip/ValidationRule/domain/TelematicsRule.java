package com.lexisnexis.telematics.infrastructure.domain;

public class TelematicsRule {

    private String ruleCode;

    private String errorMessage;

    public String getRuleCode() {
        return ruleCode;
    }

    public void setRuleCode(String ruleCode) {
        this.ruleCode = ruleCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public TelematicsRule(String ruleCode, String errorMessage) {
        this.ruleCode = ruleCode;
        this.errorMessage = errorMessage;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime
                * result
                + ((this.errorMessage == null) ? 0 : this.errorMessage
                        .hashCode());
        result = prime * result
                + ((this.ruleCode == null) ? 0 : this.ruleCode.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        TelematicsRule other = (TelematicsRule) obj;
        if (this.errorMessage == null) {
            if (other.errorMessage != null)
                return false;
        } else if (!this.errorMessage.equalsIgnoreCase(other.errorMessage))
            return false;
        if (this.ruleCode == null) {
            if (other.ruleCode != null)
                return false;
        } else if (!this.ruleCode.equalsIgnoreCase(other.ruleCode))
            return false;
        return true;
    }

}