package com.lexisnexis.telematics.infrastructure.domain;

public interface AggregateRoot<TID> extends DomainEntity<TID> {}