package com.lexisnexis.telematics.infrastructure.domain;

import java.util.List;

public interface DomainEntityValidator<T> {
	public void setRules(List<DomainRule<T>> rules);
	public List<TelematicsRule> getBrokenRules(T entity);
}