package com.lexisnexis.telematics.infrastructure.domain;

public interface ValueObject {}