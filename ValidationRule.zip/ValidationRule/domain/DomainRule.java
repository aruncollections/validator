package com.lexisnexis.telematics.infrastructure.domain;

public interface DomainRule<T> {
/*	public abstract String getRuleCode();
	public abstract String getErrorMessage();
	public abstract String isValid(T entity, String operation);	*/
	public abstract TelematicsRule getErrorMessage(T entity);
	public abstract boolean isValid(T entity);	
}
