package com.lexisnexis.telematics.driver.domain.client;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Configurable;

import com.lexisnexis.telematics.domain.carrier.Carrier;
import com.lexisnexis.telematics.domain.carrier.CarrierRepository;
import com.lexisnexis.telematics.domain.carrier.aggregate.rule.CarrierValidator;
import com.lexisnexis.telematics.driver.domain.client.rule.ClientExistsValidator;
import com.lexisnexis.telematics.driver.domain.client.rule.ClientValidator;
import com.lexisnexis.telematics.driver.domain.policy.TDPolicy;
import com.lexisnexis.telematics.driver.domain.user.User;
//import com.lexisnexis.telematics.driver.domain.policy.TDPolicy;
//import com.lexisnexis.telematics.driver.domain.account.TDAccount;
import com.lexisnexis.telematics.infrastructure.domain.DomainEntity;
import com.lexisnexis.telematics.infrastructure.domain.DomainEntityValidator;
import com.lexisnexis.telematics.infrastructure.domain.DomainEntityValidatorResolver;
import com.lexisnexis.telematics.infrastructure.domain.TelematicsRule;

@Configurable
@Entity
@Table(name="client", uniqueConstraints=@UniqueConstraint(name="client_number_unique_index", columnNames={"number"}))
public class Client implements DomainEntity<Long>  {

    private static final Logger logger = LoggerFactory.getLogger(Client.class);

    public static final String CLIENT_EXISTS_RULE_KEY = "clientExists";

    @Resource(name="domainEntityValidatorResolver")
    @Transient
    private DomainEntityValidatorResolver domainEntityValidatorResolver;

    @Resource
    @Transient
    private ClientRepository clientRepository;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name="number", nullable=false)
    private Integer number;

    @Column(name="name", nullable=false)
    private String name;

    @Column(name="description", nullable=false)
    private String description;

    //@Column(name="password_reset_from_email", nullable=false)
    //private String passwordResetFromEmail;

    @Column(name="push_apn_certificate_pass")
    private String pushApnCertificatePass;

    @Column(name="push_apn_certificate_file")
    private String pushApnCertificateFile;

    @Column(name="google_api_server_key_file")
    private String googleApiServerKeyFile;

    @Column(name="google_api_browser_key_file")
    private String googleApiBrowserKeyFile;

    @Column(name="status", nullable=false)
    @Enumerated(EnumType.STRING)
    private ClientStatusEnum status;

    @Column(name="account_number", nullable=false)
    private String accountNumber;

    @Column(name="customer_number", nullable=false)
    private String customerNumber;

    @Column(name="created_by_user", nullable=false)
    private String createdByUser;

    @Column(name="created_by_system", nullable=false)
    private String createdBySystem;

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name="client_id")
    private Set<User> users = new HashSet<User>();

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name="client_id")
    private Set<TDPolicy> policies = new HashSet<TDPolicy>();

//    @ManyToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name="td_account_id", nullable=false, updatable=true)
//    private TDAccount account;

    @Column(name="access_code")
    private String accessCode;

    @Type(type="org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    @Column(name="created_date", nullable=false, updatable=false)
    private DateTime createdDate;

    @Type(type="org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    @Column(name="modified_date", nullable=true, updatable=true)
    private DateTime modifiedDate;

    public Client ()  {
    }

    public Client(Long id, Integer number) {
        this.id = id;
        this.number = number;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public Long getId() {
        return id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getNumber() {
        return this.number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

//    public String getPasswordResetFromEmail() {
//        return this.passwordResetFromEmail;
//    }
//
//    public void setPasswordResetFromEmail(String passwordResetFromEmail) {
//        this.passwordResetFromEmail = passwordResetFromEmail;
//    }

    public String getPushApnCertificatePass() {
        return this.pushApnCertificatePass;
    }

    public void setPushApnCertificatePass(String pushApnCertificatePass) {
        this.pushApnCertificatePass = pushApnCertificatePass;
    }

    public String getPushApnCertificateFile() {
        return this.pushApnCertificateFile;
    }

    public void setPushApnCertificateFile(String pushApnCertificateFile) {
        this.pushApnCertificateFile = pushApnCertificateFile;
    }

    public String getGoogleApiServerKeyFile() {
        return this.googleApiServerKeyFile;
    }

    public void setGoogleApiServerKeyFile(String googleApiServerKeyFile) {
        this.googleApiServerKeyFile = googleApiServerKeyFile;
    }

    public String getGoogleApiBrowserKeyFile() {
        return this.googleApiBrowserKeyFile;
    }

    public void setGoogleApiBrowserKeyFile(String googleApiBrowserKeyFile) {
        this.googleApiBrowserKeyFile = googleApiBrowserKeyFile;
    }

    public ClientStatusEnum getStatus() {
        return this.status;
    }

    public void setStatus(ClientStatusEnum status) {
        this.status = status;
    }

    public String getAccountNumber() {
        return this.accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getCustomerNumber() {
        return this.customerNumber;
    }

    public void setCustomerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
    }

    public String getCreatedByUser() {
        return this.createdByUser;
    }

    public void setCreatedByUser(String createdByUser) {
        this.createdByUser = createdByUser;
    }

    public String getCreatedBySystem() {
        return this.createdBySystem;
    }

    public void setCreatedBySystem(String createdBySystem) {
        this.createdBySystem = createdBySystem;
    }

    public Set<User> getUsers() {
        //if (users == null || users.size() < 1)
        //    users = new HashSet<User>();
        return users;
    }

    public void setUsers(Set<User> users) {
        this.users = users;
    }

//    public Set<TDPolicy> getPolicies() {
//        //if (policies == null || policies.size() < 1)
//        //    policies = new HashSet<TDPolicy>();
//        return this.policies;
//    }
//
//    public void setPolicies(Set<TDPolicy> policies) {
//        this.policies = policies;
//    }

//    public TDAccount getAccount() {
//        return this.account;
//    }
//
//    public void setAccount(TDAccount account) {
//        this.account = account;
//    }

    public DateTime getCreatedDate() {
        return this.createdDate;
    }

    public void setCreatedDate(DateTime createdDate) {
        this.createdDate = createdDate;
    }

    public DateTime getModifiedDate() {
        return this.modifiedDate;
    }

    public void setModifiedDate(DateTime modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public boolean isActive() {
        return this.status == ClientStatusEnum.ACTIVE;
    }

    public String getAccessCode() {
        return accessCode;
    }

    public void setAccessCode(String accessCode) {
        this.accessCode = accessCode;
    }

    public List<TelematicsRule> getBrokenRulesForPersistence(String operation) {
        String key = operation + "Client";
         if (domainEntityValidatorResolver.getDomainValidator(key) instanceof ClientValidator) {
            DomainEntityValidator<Client> clientValidator = (ClientValidator)domainEntityValidatorResolver.getDomainValidator(key);
            return clientValidator.getBrokenRules(this);
        } else {
            logger.warn ("Could not find clientValidator: operation: "+operation);
            throw new RuntimeException("Could not find clientValidator");
        }
     }
    
    public List<TelematicsRule> getBrokenRulesForClientExists (String operation)  {
        List<TelematicsRule> brokenRules = new ArrayList<>();

        if (domainEntityValidatorResolver.getDomainValidator(operation) instanceof ClientExistsValidator) {

            logger.info ("getBrokenRulesForClientExists:::: "+operation);

            DomainEntityValidator<Client> withoutPolicyValidator = (ClientExistsValidator)domainEntityValidatorResolver.getDomainValidator(operation);

            brokenRules = withoutPolicyValidator.getBrokenRules(this);

        } else {
            logger.warn ("Could not find User: BrokenRulesForClientExists: operation: "+operation);
            throw new RuntimeException("Could not find BrokenRulesForClientExists");
        }

        return brokenRules;
    }

	public Set<TDPolicy> getPolicies() {
		return policies;
	}

	public void setPolicies(Set<TDPolicy> policies) {
		this.policies = policies;
	}

	   public TDPolicy getEffectiveTDPolicy(String accountNumber, String policyNumber) {
           return clientRepository.findTDPolicy(accountNumber, policyNumber, DateTime.now());
     }


}