package com.lexisnexis.telematics.driver.domain.client;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository("clientSettingRepository")
public interface ClientSettingsRepository extends JpaRepository<ClientSetting, Long> {
	
	public List<ClientSetting> findByClientId(final Long clientId);
	
	public ClientSetting findByClientIdAndKey(final Long clientId, final String key);
	
}
