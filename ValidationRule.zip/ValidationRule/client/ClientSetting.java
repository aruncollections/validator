package com.lexisnexis.telematics.driver.domain.client;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Configurable;

import com.lexisnexis.telematics.infrastructure.domain.DomainEntity;


@Configurable
@Entity
@Table(name = "client_setting")
public class ClientSetting implements DomainEntity<Long> {
	
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    
    @Column(name = "key", nullable=false)
    private String key;
    
    @Transient
    @Enumerated(EnumType.STRING)
    private ClientSettingKeyEnum enumKey;

    @Column(name = "value", nullable=false)
    private String value;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="client_id", nullable=false, updatable=false)
    private Client client;
    
    @Type(type="org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    @Column(name="created_date", nullable=false, updatable=true)
    private DateTime createdDate;

    @Type(type="org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    @Column(name="modified_date", nullable=false, updatable=true)
    private DateTime modifiedDate;
    
    @Override
    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public Long getId() {
        return id;
    }
    
    public void setKey(String key) {
        this.key = key;
    }

    public String getKey() {
        return this.key;
    }
    
    public void setValue(String value) {
        this.value = value;
    }

    public String getValue() {
        return this.value;
    }
  
    public Client getClient() {
        return client;
    }

    public void setClients(Client client) {
        this.client = client;
    }
    
    public DateTime getCreatedDate() {
        return this.createdDate;
    }

    public void setCreatedDate(DateTime createdDate) {
        this.createdDate = createdDate;
    }

    public DateTime getModifiedDate() {
        return this.modifiedDate;
    }

    public void setModifiedDate(DateTime modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

	public ClientSettingKeyEnum getEnumKey() {
		
		return (ClientSettingKeyEnum.fromValue(key)==null?null:ClientSettingKeyEnum.fromValue(key));
	}

	public void setEnumKey(ClientSettingKeyEnum enumKey) {
		this.enumKey = enumKey;
	}

}
