package com.lexisnexis.telematics.driver.domain.client;

public interface ClientRepositoryCustom {

}