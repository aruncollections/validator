package com.lexisnexis.telematics.driver.domain.client;


public enum ClientStatusEnum {

    ACTIVE("ACTIVE"),
    CANCELED("CANCELED");

    private final String value;

    ClientStatusEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ClientStatusEnum fromValue(String v) {
        for (ClientStatusEnum e : ClientStatusEnum.values()) {
            if (e.value().equalsIgnoreCase(v)) {
                return e;
            }
        }
        return null;
    }

}