package com.lexisnexis.telematics.driver.domain.client;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lexisnexis.telematics.domain.carrier.Carrier;
import com.lexisnexis.telematics.domain.carrier.CarrierRepository;

@Service("clientService")
public class ClientServiceImpl implements ClientService {

	@Resource(name="clientRepository")
    ClientRepository clientRepository;
	
	@Resource(name="clientSettingRepository")
    ClientSettingsRepository clientSettingRepository;
    
    @Resource(name="carrierRepository")
    CarrierRepository carrierRepository;    

    @Override
    @Transactional
    public List<Client> getAllClients () {
        return clientRepository.findAll();
    }

    @Override
    @Transactional
    public Client getById (Long id) {
        return clientRepository.findOne(id);
    }

    @Override
    @Transactional
    public Client getByNumber (Integer clientNumber) {
        return clientRepository.findByNumber (clientNumber);
    }

    @Override
    @Transactional
    public Client save (Client client) {
        return clientRepository.save (client);
    }
    
    @Override
    @Transactional
    public Carrier saveAndFlush (Carrier carrier) {
        return carrierRepository.saveAndFlush (carrier);
    }    

    @Override
    @Transactional
    public Integer getMaxNumber() {
        return clientRepository.findMaxNumber();
    }
    
    @Override
    @Transactional
    public Client getByNumberOrAccountNumber(Integer number, String accountNumber) {
        return clientRepository.findByNumberOrAccountNumber(number, accountNumber);
    }
    
    @Override
    @Transactional
    public Client getByNumberAndAccountNumber(Integer number, String accountNumber) {
        return clientRepository.findByNumberAndAccountNumber(number, accountNumber);
    }
    
    @Override
    @Transactional
    public Client getByAccessCode(String accessCode) {
        return clientRepository.findByAccessCode(accessCode);
    }

    /**
     * Method used only to establish or validate security context of current principal.  This method should
     * not be used for any other purposes.
     */
    @Override
    @Transactional 
    public Client getByPolicyIdNoSecurity(Long policyId) {
    	return clientRepository.findByPolicyId(policyId);
    }
    
    @Override
    @Transactional
    @PostAuthorize("hasPermission(returnObject, '')")
    public Client getByUserTelematicsId(String telematicsId) {
    	return clientRepository.findByUserTelematicsId(telematicsId);
    }
    
    /**
     * Method used only to establish or validate security context of current principal.  This method should
     * not be used for any other purposes.
     */
    @Override
    @Transactional
    public Client getByUserTelematicsIdNoSecurity(String telematicsId) {
    	return clientRepository.findByUserTelematicsId(telematicsId);
    }
    
    @Override
    @Transactional
  //  @PostAuthorize("hasPermission(returnObject, '')")
    public Carrier getActiveCarrierByAMBestNumber(String aMBestNumber) {
        return carrierRepository.findActiveByAMBestNumber(aMBestNumber);
    }

    @Override
    @Transactional
    public Client getActiveClientByAccountNumber(String accountNumber) {
    	return clientRepository.findByStatusAndAccountNumber(ClientStatusEnum.ACTIVE, accountNumber);
    }

    @Override
    @Transactional
	public ClientSetting getClientSetting(Long clientId, ClientSettingKeyEnum key) {
    	return clientSettingRepository.findByClientIdAndKey(clientId, key.value());
    }

    @Override
    @Transactional
    public List<ClientSetting> getClientSettings(Long clientId) {
    	return clientSettingRepository.findByClientId(clientId);
    }
}