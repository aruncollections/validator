package com.lexisnexis.telematics.driver.domain.client;

import java.util.List;

import com.lexisnexis.telematics.domain.carrier.Carrier;

public interface ClientService {

    public List<Client> getAllClients ();
    
    public Client getById(Long id);
    
    public Client getByNumber (Integer clientNumber);
    
    public Client save (Client client);
    
    public Carrier saveAndFlush(Carrier carrier);
    
    public Integer getMaxNumber();
    
    public Client getByNumberOrAccountNumber(Integer number, String accountNumber);
    
    public Client getByNumberAndAccountNumber(Integer number, String accountNumber);
    
    public Client getByAccessCode(String accessCode);
    
    public Client getByPolicyIdNoSecurity(Long policyNumber);
    
    public Client getByUserTelematicsId(String telematicsId);
    
    public Client getByUserTelematicsIdNoSecurity(String telematicsId);
    
	public Carrier getActiveCarrierByAMBestNumber(String aMBestNumber);
	
	public Client getActiveClientByAccountNumber(String accountNumber);
	
	public ClientSetting getClientSetting(Long ClientId, ClientSettingKeyEnum key);
	
	public List<ClientSetting> getClientSettings(Long clientId);
}