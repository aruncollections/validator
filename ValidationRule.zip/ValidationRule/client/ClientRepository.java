package com.lexisnexis.telematics.driver.domain.client;

import org.joda.time.DateTime;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.lexisnexis.telematics.driver.domain.policy.TDPolicy;

@Repository("clientRepository")
public interface ClientRepository extends JpaRepository<Client, Long>, ClientRepositoryCustom  {

    public Client findByNumber(Integer number);

    @Query("SELECT max(c.number) FROM Client c")
    public Integer findMaxNumber();
    
    public Client findByNumberOrAccountNumber(Integer number, String accountNumber);
    
    public Client findByNumberAndAccountNumber(Integer number, String accountNumber);
    
    public Client findByAccessCode(String accessCode);
    
    //TODOR: refine this
    @Query("SELECT tdpolicy FROM Client client JOIN client.policies tdpolicy " +
            "WHERE client.accountNumber = :accountNumber " +
    		"and tdpolicy.number = :policyNumber          " +
            "and (tdpolicy.endDate >= :endDate OR tdpolicy.endDate is null)")
    public TDPolicy findTDPolicy(@Param("accountNumber") String accountNumber, @Param("policyNumber") String policyNumber, @Param("endDate") DateTime endDate);
    
    public Client findByStatusAndAccountNumber(ClientStatusEnum status, String accountNumber);

    @Query("SELECT client FROM Client client, User user " +
            "WHERE user.telematicsId = :telematicsId " +
            "AND client.id = user.client.id")
    public Client findByUserTelematicsId(@Param("telematicsId") String telematicsId);
    
    @Query("SELECT client FROM Client client, TDPolicy policy " +
            "WHERE policy.id = :policyId " +
            "AND client.id = policy.client.id")
    public Client findByPolicyId(@Param("policyId") Long policyId);
    
}