package com.lexisnexis.telematics.driver.domain.client.rule;


import org.springframework.context.MessageSource;

import com.lexisnexis.telematics.driver.domain.client.Client;
import com.lexisnexis.telematics.domain.rule.AbstractRule;
import com.lexisnexis.telematics.infrastructure.domain.TelematicsRule;

public class ClientExistsRule extends AbstractRule<Client>  {

    public ClientExistsRule(String errorCode, MessageSource msgSource) {
        super(errorCode, msgSource);
    }

    @Override
    public TelematicsRule getErrorMessage(Client client) {
        return this.getTelematicsRule(new Object[] {null});
    }

    @Override
    public boolean isValid(Client client) {
        return true;
    }

}