package com.lexisnexis.telematics.driver.domain.client.rule;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;

import com.lexisnexis.telematics.domain.rule.AbstractRule;
import com.lexisnexis.telematics.driver.domain.client.Client;
import com.lexisnexis.telematics.infrastructure.domain.TelematicsRule;
import com.lexisnexis.telematics.infrastructure.esp.driver.insurancecontextlookup.InsuranceContextLookupService;

public class AccountNotExistsRule extends AbstractRule<Client> {

    private static final Logger logger = LoggerFactory.getLogger(AccountNotExistsRule.class);
            
	private InsuranceContextLookupService insuranceContextLookupService;
	 
	public void setInsuranceContextLookupService(InsuranceContextLookupService insuranceContextLookupService) {
		this.insuranceContextLookupService = insuranceContextLookupService;
	}

	public AccountNotExistsRule(String errorCode, MessageSource msgSource) {
		super(errorCode, msgSource);
	}
	
	@Override
	public TelematicsRule getErrorMessage(Client client) {

		return this.getTelematicsRule(new Object[] {client.getCustomerNumber()});
	}
	
	@Override
	public boolean isValid(Client client) {
	    logger.debug("Client number: " + client.getNumber() + ", Customer number: " + client.getCustomerNumber());
	    
		String value = client.getCustomerNumber();
		String espCustomerNumber = insuranceContextLookupService.getCustomerNumberForAccountNumber(client.getAccountNumber());
		
		logger.debug("espCustomerNumber: " + espCustomerNumber);
		
		//Ensure Customer number returned from ESP service matches customer number for Account Carrier.
		return ((value != null) && value.equals(espCustomerNumber)) ;
	}

}
