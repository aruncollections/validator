package com.lexisnexis.telematics.driver.domain.client.rule;

import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;

import com.lexisnexis.telematics.domain.rule.AbstractRule;
import com.lexisnexis.telematics.driver.domain.client.Client;
import com.lexisnexis.telematics.infrastructure.domain.TelematicsRule;
import com.lexisnexis.telematics.infrastructure.security.SecurityUtil;
import com.lexisnexis.telematics.infrastructure.security.access.Roles;
import com.lexisnexis.telematics.infrastructure.security.mea.MaeUserDetails;

public class AccountNotAllowedRule extends AbstractRule<Client> {
    
    private static final Logger logger = LoggerFactory.getLogger(AccountNotAllowedRule.class);

	public AccountNotAllowedRule(String errorCode, MessageSource msgSource) {
		super(errorCode, msgSource);
	}
	
	@Override
	public TelematicsRule getErrorMessage(Client client) {

		return this.getTelematicsRule(new Object[] {client.getAccountNumber()});
	}
	
	@Override
	public boolean isValid(Client client) {
	    logger.debug("Client Id: " + client.getNumber());
		String value = client.getAccountNumber();
		
		//Account Number not required for this rule
		if (value == null) return true;
		if (value.trim().isEmpty()) return true;
		
		MaeUserDetails securityUserDetails = (MaeUserDetails)SecurityUtil.getUserDetailsForCurrentUser();
		if (securityUserDetails != null) {
			if (SecurityUtil.hasRole(securityUserDetails, Roles.ACCESS)) {
			    logger.debug("MaeUserDetails having Roles.ACCESS");
				return true;
			}
			
			@SuppressWarnings("unchecked")
			Set<String> accountNumbers = (Set<String>) securityUserDetails.getAccountNumbers();
			if (accountNumbers != null
					&& accountNumbers.contains(value)) {
				return true;
			}
		} else {
		    //TODO
		    return true;
		}
		
		return false;
	}
}
