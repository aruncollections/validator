package com.lexisnexis.telematics.driver.domain.client.rule;

import org.springframework.context.MessageSource;

import com.lexisnexis.telematics.domain.rule.AbstractRule;
import com.lexisnexis.telematics.driver.domain.client.Client;
import com.lexisnexis.telematics.infrastructure.domain.TelematicsRule;

public class InvalidAccountNumberRule extends AbstractRule<Client> {

	public InvalidAccountNumberRule(String errorCode, MessageSource msgSource) {
		super(errorCode, msgSource);
	}
	
	@Override
	public TelematicsRule getErrorMessage(Client client) {

		return this.getTelematicsRule(new Object[] {client.getAccountNumber()});
	}
	
	@Override
	public boolean isValid(Client client) {
		String value = client.getAccountNumber();
		
		//Account Number required
		if (value == null) return false;
		if (value.trim().isEmpty()) return false;
		
		//Account Number length may only be 6 or 8
		return (value.length() == 6 || value.length() == 9) ;
	}


}
