package com.lexisnexis.telematics.driver.domain.client.rule;

import org.springframework.stereotype.Service;

import com.lexisnexis.telematics.driver.domain.client.Client;
import com.lexisnexis.telematics.domain.rule.DomainEntityValidatorImpl;


@Service("clientExistsValidator")
public class ClientExistsValidator extends DomainEntityValidatorImpl<Client> {}