package com.lexisnexis.telematics.domain.rule;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.lexisnexis.telematics.infrastructure.domain.DomainEntityValidator;
import com.lexisnexis.telematics.infrastructure.domain.DomainEntityValidatorResolver;

@Component(value="domainEntityValidatorResolver")
public class DomainEntityValidatorResolverImpl implements DomainEntityValidatorResolver {

    @Resource(name="validatorMap")
    Map<String, DomainEntityValidator<?>> validatorMap;

    @Resource(name="driverValidatorMap")
    Map<String, DomainEntityValidator<?>> driverValidatorMap;

    @Resource(name="driverBatchValidatorMap")
    Map<String, DomainEntityValidator<?>> driverBatchValidatorMap;
    
    public DomainEntityValidator<?> getDomainValidator(String operation) {        
        if (validatorMap.get(operation) != null)
            return validatorMap.get(operation);
        else if(driverValidatorMap.get(operation) != null)
            return driverValidatorMap.get(operation);
        else 
            return driverBatchValidatorMap.get(operation);
    }
}
