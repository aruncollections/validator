package com.lexisnexis.telematics.domain.rule;

import org.joda.time.DateTime;

public class RuleValidationUtil {

	public static boolean isDateValid(DateTime value) {
		
		//Start date is required
		if (value == null) return false;
		
		DateTime today = DateTime.now().toDateMidnight().toDateTime();
		
		//Start date should not be in the past
		if (value.isBefore(today)) return false;
		
		//Start date cannot be more than 90 days from now.
		return value.isBefore(DateTime.now().plusDays(91));
	}
	
	public static boolean isDateCurrent(DateTime value) {
		//current date
		DateTime beginDay = DateTime.now().toDateMidnight().toDateTime();
		DateTime endDay = DateTime.now().plusDays(1).toDateMidnight().toDateTime().minusMillis(1);
		
		if ((value.isBefore(beginDay)) || (value.isAfter(endDay)))
			return false;
		
		return true;
	}
	
}