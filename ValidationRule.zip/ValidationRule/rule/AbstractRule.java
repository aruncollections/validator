package com.lexisnexis.telematics.domain.rule;

import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.DateTimeFormatterBuilder;
import org.joda.time.format.DateTimeParser;
import org.springframework.context.MessageSource;

import com.lexisnexis.telematics.infrastructure.domain.DomainRule;
import com.lexisnexis.telematics.infrastructure.domain.TelematicsRule;

public abstract class AbstractRule<T> implements DomainRule<T> {

    private String errorCode;

    private MessageSource msgSource;

    protected DateTimeParser[] parsers = { DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss").getParser(),
            DateTimeFormat.forPattern("yyyy-MM-dd").getParser() };

    protected DateTimeFormatter formatter = new DateTimeFormatterBuilder().append(null, parsers).toFormatter();

    public AbstractRule(String errorCode, MessageSource msgSource) {
        this.errorCode = errorCode;
        this.msgSource = msgSource;
    }

    public TelematicsRule getTelematicsRule(Object[] args) {
        String message = msgSource.getMessage(errorCode, args, null);
        String[] arrMsg = message.split("\\|");
        TelematicsRule teleRule = new TelematicsRule(arrMsg[0], arrMsg[1]);
        return teleRule;
    }

    public String getErrorCode() {
        return errorCode;
    }

}
