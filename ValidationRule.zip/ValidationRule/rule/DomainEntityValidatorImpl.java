package com.lexisnexis.telematics.domain.rule;

import java.util.ArrayList;
import java.util.List;

import com.lexisnexis.telematics.infrastructure.domain.DomainEntityValidator;
import com.lexisnexis.telematics.infrastructure.domain.DomainRule;
import com.lexisnexis.telematics.infrastructure.domain.TelematicsRule;

public class DomainEntityValidatorImpl<T> implements DomainEntityValidator<T> {
	private List<DomainRule<T>> rules;

	@Override
	public void setRules(List<DomainRule<T>> rules) {
		this.rules = rules;
	}	
	
	@Override
	public List<TelematicsRule> getBrokenRules(T entity) {
		List<TelematicsRule> telematicBrokenRules = new ArrayList<>();
		if (this.rules == null) return telematicBrokenRules;
		
		for (DomainRule<T> domainRule : this.rules) {
			boolean isValid = domainRule.isValid(entity);

			if (!isValid) {
				telematicBrokenRules.add(domainRule.getErrorMessage(entity));
			}
		}
		return telematicBrokenRules;
	}
}
